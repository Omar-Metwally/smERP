﻿namespace smERP.Domain.Entities.User;

public class Customer : BaseUser
{
}
