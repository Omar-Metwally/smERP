﻿namespace smERP.Domain.Entities;

public class BaseEntity
{
    public int Id { get; set; }
    public bool IsHidden { get; set; }
}
