﻿namespace smERP.Domain.Entities;

public class BaseEntity
{
    public int ID { get; set; }
    public bool IsHidden { get; set; }
}
