﻿namespace smERP.Application.Interfaces.Repositories;

public interface IRepository<T> where T : class
{
    Task<T> GetByID(int ID);
    Task<IEnumerable<T>> GetAll();
    Task Add(T entity);
    Task<bool> DoesExist(int ID);
    Task<int> CountExisting(IEnumerable<int> IDs);
    void Update(T entity);
    Task Hide(int ID);
}
