﻿namespace smERP.Enums;

public enum TransactionStatus
{
    NOTPAID,
    PARTLYPAID,
    FULLYPAID
}
