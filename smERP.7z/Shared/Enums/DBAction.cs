﻿namespace smERP.Enums;

public enum DBAction
{
    INSERT,
    UPDATE,
    DELETE,
    READ
}
