﻿using Microsoft.EntityFrameworkCore;
using smERP.Application.Interfaces.Repositories;
using smERP.Domain.Entities;
using smERP.Infrastructure.Data;

namespace smERP.Infrastructure.Repositories;

public class Repository<TEntity>(DBContext context) : IRepository<TEntity> where TEntity : BaseEntity
{
    protected readonly DBContext _context = context;

    public async Task<TEntity> GetByID(int ID)
    {
        return await _context.Set<TEntity>().FirstOrDefaultAsync(x => x.ID == ID);
    }

    public async Task<IEnumerable<TEntity>> GetAll()
    {
        return await _context.Set<TEntity>().ToListAsync();
    }

    public async Task Add(TEntity entity)
    {
        await _context.Set<TEntity>().AddAsync(entity);
    }

    public void Update(TEntity entity)
    {
        _context.Set<TEntity>().Update(entity);
    }

    public async Task Hide(int ID)
    {
        var entityToBeHidden = await _context.Set<TEntity>().AsTracking().FirstOrDefaultAsync(x => x.ID == ID);
        if (entityToBeHidden is not null)
            entityToBeHidden.IsHidden = true;
    }

    public async Task<bool> DoesExist(int ID)
    {
        return await _context.Set<TEntity>().AnyAsync(x => x.ID == ID);
    }

    public async Task<int> CountExisting(IEnumerable<int> IDs)
    {
        return await _context.Set<TEntity>().CountAsync(x => IDs.Contains(x.ID));
    }
}

